# Dragon-Tale-Game
Dragon Tale Platformer Game

Written in Fall 2014 when I was first starting out with Java Programming.  With the help of a youtube tutorial series
(starting with https://www.youtube.com/watch?v=9dzhgsVaiSo) I was able to understand how to lay out the basic foundation 
of the game.  After I had the foundation down, I started to play around with different ideas I could add to the game. I 
had a great time adding additional levels, bosses, power-ups, monsters, and mechanics.  Figuring out how to translate 
my ideas into working code was an interesting experience to say the least.
